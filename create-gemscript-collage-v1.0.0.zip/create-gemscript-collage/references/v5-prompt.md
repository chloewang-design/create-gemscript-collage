# V5 GemScript generation prompt

Replace all braces before use. Keep the positive and avoid instructions in the same prompt.

```text
Use case: style-transfer
Asset type: independent 3:2 landscape editorial collage

Use the uploaded photograph as the sole subject reference. Preserve the recognizable identity, appearance, expression, pose, structure, and essential visual features of {SUBJECT}. Create a new independent collage image. Do not include the full original photograph outside the collage and do not make a before-and-after comparison.

PHOTO:
Transform the source into one small vintage black-and-white silver-gelatin film print. Crop more tightly than the original so the main subject is clear and prominent. Simplify distracting modern or overly complex background details while retaining enough context to identify the scene.

Use true high-contrast black and white: deep blacks, clean pale highlights, delicate analog grain, a thin slightly worn off-white photographic border, and a soft realistic contact shadow. Give the photograph an extremely subtle 5–8% {BACKGROUND_TONE}-gray tint in its highlights and midtones while keeping it recognizably black and white. No strong monochrome cast and no sepia.

BACKGROUND:
Use a full-bleed {BACKGROUND_HUE} paper background derived from or complementary to the source. Keep it high in lightness, low in saturation, slightly gray, soft, and airy so the rhinestones remain the main color accent. Use almost invisible matte paper grain.

LETTERING:
Create the exact text “{CUSTOM_TEXT}” as elegant connected English calligraphy formed entirely from hundreds of tiny flat-back faceted rhinestone stickers. Reproduce the spelling, capitalization, and spaces verbatim. Do not add, remove, or substitute letters.

For one word, use one flowing calligraphic line. For two words or a name, use a lightly staggered two-line signature composition when needed, with a clear visual space between the words and a short connecting flourish. Keep the text immediately readable. Use distinctive capitals, clearly separated repeated letters, open counters, and a visible rhinestone dot above every lowercase i.

RHINESTONE MATERIAL:
Use tiny 2–7 mm low-profile flat-back acrylic rhinestone stickers with crisp cut facets, small highlights, adhesive flatness, and delicate close shadows. They must look like handmade craft stickers, not loose jewelry.

Build the strokes from an irregular mixture of round gems, ovals, squares, emerald-cut rectangles, diamonds, teardrops, marquise shapes, five-point stars, tiny flowers, and occasional hearts. Use small round gems as the connective base and place special shapes at bends, joins, thick downstrokes, and flourish accents. Avoid predictable repeating sequences.

Use a dopamine palette of cobalt blue, turquoise, emerald, lime, hot pink, cherry red, violet, lemon yellow, pale lilac, and clear crystal. Alternate colors organically so they contrast with the restrained background.

COMPOSITION:
Place the vintage film print {PHOTO_POSITION}. Arrange the rhinestone text across the left and lower-middle portion of the canvas. Keep the complete arrangement at approximately 80–83% of the available canvas area. The lettering should be delicate rather than oversized. Maintain at least 8–10% clean outer margin on all sides, with generous breathing room above and below.

Create believable physical interaction: let the terminal rhinestone swash travel toward the photograph, disappear underneath its lower-left edge, then reappear briefly along the bottom border. Place a few gems on top of the off-white border and allow only 2–3 tiny gems into an empty area inside the photograph. Never cover the main subject or important details.

LOOSE RHINESTONE ACCENTS:
Add only 12–16 separate rhinestones in three independent, incomplete, asymmetric movement paths:
1. A loose upward-curving trail above the beginning of the word, denser near the lettering and opening outward.
2. A short interrupted diagonal trail beside the photograph, with one isolated gem farther away.
3. A sparse shallow curve beneath the terminal flourish.

Use irregular spacing, varied sizes, mixed shapes, different densities, and fading endpoints. The accents should feel naturally displaced by movement, not evenly sprinkled.

STYLE:
Premium handmade mixed-media editorial still life photographed directly from above. Tactile paper, photographic print, and rhinestone materials; refined Y2K nostalgia, subtle retro dreamcore atmosphere, controlled asymmetry, and generous negative space.

AVOID:
misspelled text, extra or missing letters, incorrect capitalization, merged words without a space, unreadable calligraphy, printed ink beneath rhinestones, full-size original photo, split-screen comparison, oversized lettering, cramped edges, elements touching the canvas boundary, evenly spaced gems, symmetrical decoration, circular borders, dense random confetti, unrelated clusters, one-shape-only decoration, dark or saturated background, neon colors, heavy paper texture, strong film tint, sepia, muddy gray photograph, weak black-and-white contrast, altered subject identity, covered faces or key details, metallic chains, wire, string, pearls, beads with holes, thick puffy gel stickers, inflated plastic, large cabochons, oversized loose gemstones, jewelry-like objects, captions, logos, watermarks, or interface elements.
```
