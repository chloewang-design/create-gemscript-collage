---
name: create-gemscript-collage
description: Turn a raster photo into a V5 GemScript collage with a high-contrast vintage black-and-white film print, a high-lightness low-saturation Morandi paper background, multicolor flat-back rhinestone calligraphy using exact custom text, sparse gem movement trails, and an automatic 3:4 composite that stacks the effect above the untouched original. Use for GemScript, rhinestone-script, Y2K jewel-sticker, vintage-film collage, custom English word or name, and effect-plus-original image requests.
---

# Create GemScript Collage

Create a 3:2 GemScript effect image, then deterministically stack it above the real source photo in a 3:4 final PNG. Never ask the image model to redraw the lower half.

## Workflow

1. Inspect the source photo with the available image viewer.
2. Resolve the lettering:
   - Reproduce user-provided English text verbatim, including capitalization and spaces.
   - If none is provided, choose one short English word, or at most two short words, that fit the photo.
3. Choose a restrained background hue derived from or complementary to the source. Keep it high-lightness, low-saturation, and slightly gray.
4. Read [references/v5-prompt.md](references/v5-prompt.md) completely and replace every placeholder before generation.
5. Use the built-in image-generation workflow. If an `imagegen` skill is available, load and follow it before calling the image tool. Treat the uploaded photo as the subject reference and generate one independent 3:2 landscape effect image.
6. Inspect the effect and validate:
   - exact text and readable letterforms;
   - recognizable subject and appropriate crop;
   - high-contrast black-and-white film with only a faint background tint;
   - high-lightness low-saturation background;
   - generous 8–10% outer margins;
   - rhinestone word and film physically overlap;
   - only three sparse, asymmetric loose-gem movement trails;
   - no extra text, logo, watermark, split screen, or original photo outside the film.
7. If validation fails, make one targeted image edit and inspect again. Do not change unrelated details.
8. Save the accepted effect non-destructively as `<source-stem>-gemscript-effect.png` in the user's working or requested output directory.
9. Choose normalized original-photo crop focus coordinates after inspection: `0.0` is left/top and `1.0` is right/bottom. Default to `0.5,0.5` only when the subject is already centered.
10. Load the bundled workspace dependencies and use the returned Python executable. This avoids assuming the system Python has Pillow. Run the deterministic compositor:

```bash
<workspace-python> <skill-dir>/scripts/compose_vertical.py \
  --effect <effect.png> \
  --original <source-photo> \
  --output <source-stem>-gemscript-final-3x4.png \
  --focus-x <0..1> \
  --focus-y <0..1>
```

11. Inspect the final PNG. Verify a 3:4 canvas, equal 3:2 halves, effect on top, the real source on the bottom, no gap or divider, and no damaged subject crop.
12. Deliver both the effect PNG and the final 3:4 PNG. Lead with the final composite.

## Output Rules

- Default half size: `1536×1024`; final size: `1536×2048`.
- Preserve the source file unchanged.
- Do not overwrite existing outputs; add a version suffix or pass `--force` only when replacement is explicitly requested.
- Skip composition only when the user explicitly asks for the effect image alone.
